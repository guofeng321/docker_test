<template>
<div>

</div>
</template>

<script>
import {ajaxhttps} from '../assets/js/api.js'
export default {
 components: {
       
 },
 props: {
 },
 data() {
   return {
       
   }
 },
 watch: {
       
 },
 computed: { 
       
 },
 methods: { 
       
 },
 created() {
       ajaxhttps.post();
},
 mounted() {
       
}
}
</script>

<style lang='less' scoped>

</style>
