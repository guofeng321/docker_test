<template>
<div>
    <div style="width:100px;height:200px;overflow:scroll;position:relative">
        <div style="height:300px"></div>
        <div style="position:absolute;bottom:0;left:0;right:0">3213213</div>
    </div>
</div>
</template>

<script>
export default {
 components: {
       
 },
 props: {
 },
 data() {
   return {
       
   }
 },
 watch: {
       
 },
 computed: { 
       
 },
 methods: { 
       
 },
 created() {
       
},
 mounted() {
       
}
}
</script>

<style lang='less' scoped>

</style>
