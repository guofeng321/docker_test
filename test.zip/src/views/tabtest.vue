<template>
<div>
    <Tab :items="titles" class="list" :height="'200px'">
        <div :slot="0">
            <br>1
            <br>1
            <br>1
            <br>1
            <br>1
            <br>1
            <br>1
            <br>1
            <br>1
            <br>1
            <br>1
            <br>1
            <br>1
            <br>1
            <br>1
            <br>1
            <br>1
            <br>1
            <br>1
            <br>1
            <br>1
            <br>1
            <br>1
            <br>1
            <br>1
        </div>
        <div :slot="1">
<br>2
            <br>2
            <br>2
            <br>2
            <br>2
            <br>2
            <br>2
            <br>2
            <br>2
            <br>2
            <br>2
            <br>2
            <br>2
            <br>2
            <br>2
            <br>2
            <br>2
            <br>2
            <br>2
            <br>2
            <br>2
            <br>2
            <br>2
            <br>2
            <br>2
            <br>2
            <br>2
            <br>2
            <br>2
            <br>2
            <br>2
            <br>2
            <br>2
            <br>2
            <br>2
            <br>2
            <br>2
            <br>2
            <br>2
            <br>2
            <br>2
            <br>2
            <br>2
            <br>2
            <br>2<br>2
            <br>2
            <br>2
            <br>2
            <br>2
        </div>
        <div :slot="2">
<br>3
            <br>3
            <br>3
            <br>3
            <br>3
            <br>3
            <br>3
            <br>3
            <br>3
            <br>3
            <br>3
            <br>3
            <br>3
            <br>3
            <br>3
            <br>3
            <br>3
            <br>3
            <br>3
            <br>3
            <br>3
            <br>3
            <br>3
            <br>3
            <br>3
            <br>3
            <br>3
            <br>3
            <br>3
            <br>3
            <br>3
            <br>3
            <br>3
            <br>3
            <br>3
        </div>
    </Tab>
</div>
</template>

<script>
import Tab from '@/components/tab'
export default {
    data() {
        return {
            titles: ["异常设备", "离线设备", "正常设备"]
        }
    },
 components: {
     Tab
 },
 props: {
 },
 watch: {
 },
 computed: { 
 },
 methods: { 
 },
 created() {
},
 mounted() {
}
}
</script>

<style lang='scss' scoped>

</style>
